﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using PS.SuperNDT.UI.Models;
using PS.SuperNDT.UI.Services;

namespace PS.SuperNDT.UI.ViewModels;

public sealed class ReportViewModel : INotifyPropertyChanged
{
    private readonly ReportService _reportService = new();

    private ReportModel? _selectedReport;

    public ObservableCollection<ReportModel> Reports { get; } = new();

    public ReportModel? SelectedReport
    {
        get => _selectedReport;
        set
        {
            if (_selectedReport == value)
                return;

            _selectedReport = value;
            OnPropertyChanged();
        }
    }

    public ReportViewModel()
    {
        Refresh();
    }

    public void Refresh()
    {
        Reports.Clear();

        foreach (var report in _reportService.GetAll())
            Reports.Add(report);
    }

    public void AddReport(ReportModel report)
    {
        _reportService.Add(report);
        Refresh();
    }

    public void DeleteReport(string reportNumber)
    {
        _reportService.Delete(reportNumber);
        Refresh();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}