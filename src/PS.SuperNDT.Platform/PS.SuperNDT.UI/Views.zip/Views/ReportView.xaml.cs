﻿using System.Windows.Controls;
using PS.SuperNDT.UI.ViewModels;

namespace PS.SuperNDT.UI.Views;

public partial class ReportView : UserControl
{
    public ReportView()
    {
        InitializeComponent();

        DataContext = new ReportViewModel();
    }
}